import React from "react";
import { 
  Cpu, 
  BookOpen, 
  Layers, 
  HelpCircle, 
  Star, 
  MessageSquare, 
  CheckCircle2, 
  ShieldCheck, 
  Lightbulb, 
  Sparkles,
  Search,
  ShoppingCart,
  MapPin,
  Clock,
  ArrowUpRight
} from "lucide-react";

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import CourseCard from "./components/CourseCard";
import ProductCard from "./components/ProductCard";
import Cart from "./components/Cart";
import AIAssistant from "./components/AIAssistant";
import EnrollModal from "./components/EnrollModal";
import Footer from "./components/Footer";
import ServicesSection from "./components/ServicesSection";
import TechBackgroundAnimation from "./components/TechBackgroundAnimation";

import { COURSES, PRODUCTS, TESTIMONIALS, FAQS } from "./data";
import { Course, Product, CartItem } from "./types";

export default function App() {
  const [activeSection, setActiveSection] = React.useState("home");
  const [cart, setCart] = React.useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = React.useState(false);
  const [isAIOpen, setIsAIOpen] = React.useState(false);
  const [selectedCourse, setSelectedCourse] = React.useState<Course | null>(null);
  const [selectedServiceId, setSelectedServiceId] = React.useState<string>("web-development");

  // Filter States
  const [courseQuery, setCourseQuery] = React.useState("");
  const [courseCategory, setCourseCategory] = React.useState<"all" | "iot" | "programming" | "robotics" | "ai">("all");

  const [productQuery, setProductQuery] = React.useState("");
  const [productCategory, setProductCategory] = React.useState<"all" | "kit" | "sensor" | "tools">("all");

  // FAQ open states
  const [openFaqId, setOpenFaqId] = React.useState<string | null>(null);

  // Cart Functions
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateCartQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Filter Logic
  const filteredCourses = COURSES.filter((course) => {
    const matchesSearch = course.title.toLowerCase().includes(courseQuery.toLowerCase()) ||
                          course.description.toLowerCase().includes(courseQuery.toLowerCase());
    const matchesCategory = courseCategory === "all" || course.category === courseCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(productQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(productQuery.toLowerCase());
    const matchesCategory = productCategory === "all" || product.category === productCategory;
    return matchesSearch && matchesCategory;
  });

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const toggleFaq = (id: string) => {
    setOpenFaqId(openFaqId === id ? null : id);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="min-h-screen bg-tech-dynamic flex flex-col font-sans relative overflow-x-hidden" id="app-root-container">
      
      {/* 0. TECH ANIMATION BACKGROUND */}
      <TechBackgroundAnimation />
      
      {/* 1. STICKY NAVBAR */}
      <Navbar
        cartCount={totalCartCount}
        onCartClick={() => setIsCartOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        onOpenConsult={() => setIsAIOpen(true)}
        onSelectService={(serviceId) => setSelectedServiceId(serviceId)}
      />

      {/* 2. HERO BANNER */}
      <Hero
        onExploreCourses={() => scrollToSection("courses")}
        onOpenConsult={() => setIsAIOpen(true)}
      />

      {/* 3. CORE VALUES SECTION (BENTO GRID STYLE) */}
      <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="values-section">
        <div className="text-center space-y-3 mb-10">
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
            Kelebihan Lembaga
          </span>
          <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
            Mengapa Memilih Barokah Tech Jambi Academy?
          </h2>
          <p className="text-sm text-slate-300 max-w-xl mx-auto">
            Kami mendedikasikan seluruh kurikulum dan kualitas pelayanan demi keberkahan dan kompetensi nyata Anda.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Card 1: Syariah Amanah */}
          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-3 hover:border-emerald-200 transition-colors">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <h3 className="font-sans font-bold text-base text-slate-800">
              Amanah & Syariah
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Jual beli tanpa riba, tanpa denda tersembunyi. Spesifikasi starter kit dipaparkan jujur, transaksi transparan dan halal.
            </p>
          </div>

          {/* Card 2: Hands-on Practical */}
          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-3 hover:border-emerald-200 transition-colors">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <Cpu className="h-5 w-5" />
            </div>
            <h3 className="font-sans font-bold text-base text-slate-800">
              100% Praktik Nyata
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Kurikulum dirancang fokus pada perakitan modul fisik, sensor industri, dan penulisan baris kode nyata tanpa bertele-tele.
            </p>
          </div>

          {/* Card 3: Free AI Support */}
          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-3 hover:border-emerald-200 transition-colors">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <Sparkles className="h-5 w-5" />
            </div>
            <h3 className="font-sans font-bold text-base text-slate-800">
              AI Smart Advisor 24/7
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Konsultasi pemilihan kelas dan pendampingan troubleshooting sirkuit koding dipandu secara instan oleh Asisten AI pintar.
            </p>
          </div>

          {/* Card 4: Lifetime Support */}
          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-3 hover:border-emerald-200 transition-colors">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <Lightbulb className="h-5 w-5" />
            </div>
            <h3 className="font-sans font-bold text-base text-slate-800">
              Grup Alumni Selamanya
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Setelah lulus, Anda tetap tergabung dalam grup WA eksklusif untuk bertanya seputar proyek teknologi Anda ke instruktur kami.
            </p>
          </div>
        </div>
      </section>

      {/* 3B. SERVICES SECTION */}
      <ServicesSection
        selectedServiceId={selectedServiceId}
        onSelectServiceId={setSelectedServiceId}
      />

      {/* 4. COURSES CATALOG SECTION */}
      <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" id="courses">
        <div className="bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl rounded-3xl p-6 sm:p-12">
          
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div className="space-y-2">
              <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider block">
                Program Unggulan
              </span>
              <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-slate-800 tracking-tight">
                Kursus & Pelatihan Terlaris
              </h2>
              <p className="text-sm text-slate-500 max-w-xl">
                Tingkatkan keahlian teknik Anda. Pilih kategori yang diminati dan mulai pendaftaran dengan mudah.
              </p>
            </div>

            {/* Course category pills filter */}
            <div className="flex flex-wrap gap-1.5 pt-2">
              {[
                { id: "all", label: "Semua Kategori" },
                { id: "iot", label: "IoT" },
                { id: "robotics", label: "Robotika" },
                { id: "programming", label: "Pemrograman" },
                { id: "ai", label: "AI & Python" }
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCourseCategory(cat.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                    courseCategory === cat.id
                      ? "bg-emerald-600 text-white shadow-sm shadow-emerald-600/10"
                      : "bg-white hover:bg-slate-100 text-slate-600 border border-slate-200"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Search bar courses */}
          <div className="max-w-md relative mb-6">
            <input
              type="text"
              value={courseQuery}
              onChange={(e) => setCourseQuery(e.target.value)}
              placeholder="Cari nama kursus atau materi..."
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs bg-white text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
          </div>

          {/* Course Grid layout */}
          {filteredCourses.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-2">
              <p className="text-sm text-slate-500 font-semibold">Tidak ada program kursus yang cocok</p>
              <button 
                onClick={() => { setCourseQuery(""); setCourseCategory("all"); }} 
                className="text-xs text-emerald-600 font-bold hover:underline"
              >
                Reset Filter Pencarian
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard
                  key={course.id}
                  course={course}
                  onEnrollClick={(course) => setSelectedCourse(course)}
                />
              ))}
            </div>
          )}

        </div>
      </section>

      {/* 5. E-COMMERCE PRODUCTS CATALOG SECTION */}
      <section className="py-14 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="products">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div className="space-y-2">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
              Gudang Komponen
            </span>
            <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
              Toko Alat Belajar & Starter Kit
            </h2>
            <p className="text-sm text-slate-300 max-w-xl">
              Dapatkan modul mikrokontroler original, sensor industri, dan alat teknik berkualitas. Garansi ganti baru bila rusak saat pengiriman.
            </p>
          </div>

          {/* Product category filter */}
          <div className="flex flex-wrap gap-1.5 pt-2">
            {[
              { id: "all", label: "Semua Alat" },
              { id: "kit", label: "Starter Kit" },
              { id: "tools", label: "Peralatan & Multitester" }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setProductCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  productCategory === cat.id
                    ? "bg-emerald-500 text-slate-950 font-bold"
                    : "bg-slate-900/60 hover:bg-slate-800 text-slate-300 border border-slate-800"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Search bar products */}
        <div className="max-w-md relative mb-6">
          <input
            type="text"
            value={productQuery}
            onChange={(e) => setProductQuery(e.target.value)}
            placeholder="Cari nama alat, komponen, atau solder..."
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs bg-white text-slate-800 outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
        </div>

        {/* Product Grid layout */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-2">
            <p className="text-sm text-slate-500 font-semibold">Komponen/alat tidak ditemukan</p>
            <button 
              onClick={() => { setProductQuery(""); setProductCategory("all"); }} 
              className="text-xs text-emerald-600 font-bold hover:underline"
            >
              Reset Pencarian Alat
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}
      </section>

      {/* 6. TESTIMONIALS SECTION */}
      <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" id="testimonials">
        <div className="bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl rounded-3xl p-6 sm:p-12">
          <div className="text-center space-y-2 mb-10">
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider block">
              Bukti Keberkahan
            </span>
            <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-slate-800 tracking-tight">
              Apa Kata Alumni & Pelanggan Kami?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((test) => (
              <div 
                key={test.id} 
                className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center text-amber-400 gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${i < test.rating ? "fill-current" : "text-slate-200"}`} 
                      />
                    ))}
                  </div>
                  <p className="text-xs text-slate-600 italic leading-relaxed">
                    "{test.comment}"
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2 border-t border-slate-50">
                  <img 
                    src={test.avatar} 
                    alt={test.name} 
                    className="h-9 w-9 object-cover rounded-full border border-slate-100"
                  />
                  <div>
                    <h4 className="font-sans font-bold text-xs text-slate-800">{test.name}</h4>
                    <span className="text-[10px] text-slate-400 block">{test.role}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. ACCORDION FAQ SECTION */}
      <section className="py-14 sm:py-16 max-w-4xl mx-auto px-4 sm:px-6" id="faq">
        <div className="text-center space-y-2 mb-10">
          <HelpCircle className="h-8 w-8 text-emerald-400 mx-auto" />
          <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
            Tanya Jawab Terkait Pelatihan & Alat
          </h2>
          <p className="text-sm text-slate-300">
            Berikut adalah jawaban dari beberapa pertanyaan yang paling sering diajukan calon siswa Barokah Tech Jambi Academy.
          </p>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq) => {
            const isOpen = openFaqId === faq.id;
            return (
              <div 
                key={faq.id} 
                className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden"
              >
                <button
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full px-5 py-4 flex items-center justify-between text-left font-sans font-bold text-xs text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
                  id={`faq-btn-${faq.id}`}
                >
                  <span>{faq.question}</span>
                  <span className={`text-emerald-600 font-extrabold transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </button>
                
                {isOpen && (
                  <div className="px-5 pb-4 pt-1 text-xs text-slate-500 border-t border-slate-100/50 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 8. MODAL ENROLL FORM & RECEIPT (CONDITIONAL) */}
      <EnrollModal
        course={selectedCourse}
        isOpen={selectedCourse !== null}
        onClose={() => setSelectedCourse(null)}
      />

      {/* 9. MODAL CART DRAWER & CHECKOUT (CONDITIONAL) */}
      <Cart
        items={cart}
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* 10. FLOATING CHAT AI ADVISOR */}
      <AIAssistant
        isOpen={isAIOpen}
        onOpen={() => setIsAIOpen(true)}
        onClose={() => setIsAIOpen(false)}
      />

      {/* 11. FOOTER CONTACT MAPS INFORMATION */}
      <Footer onNavClick={scrollToSection} />

    </div>
  );
}
