export interface Course {
  id: string;
  title: string;
  category: "iot" | "programming" | "robotics" | "ai";
  categoryLabel: string;
  level: "Pemula" | "Menengah" | "Mahir";
  duration: string;
  priceOnline: number;
  priceOffline: number;
  description: string;
  image: string;
  syllabus: string[];
  features: string[];
}

export interface Product {
  id: string;
  name: string;
  category: "kit" | "sensor" | "tools";
  categoryLabel: string;
  price: number;
  stock: number;
  rating: number;
  reviewsCount: number;
  description: string;
  image: string;
  specs: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatar: string;
  rating: number;
  comment: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}

export interface ChatMessage {
  sender: "user" | "bot";
  text: string;
  timestamp: Date;
}
