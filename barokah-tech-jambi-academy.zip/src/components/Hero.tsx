import { ArrowRight, Sparkles, ShieldCheck, PlayCircle, BookOpen } from "lucide-react";

interface HeroProps {
  onExploreCourses: () => void;
  onOpenConsult: () => void;
}

export default function Hero({ onExploreCourses, onOpenConsult }: HeroProps) {
  return (
    <div className="py-8 sm:py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" id="hero-section">
      <div className="bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl rounded-3xl p-6 sm:p-12 relative overflow-hidden">
        {/* Decorative Background Accents */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-96 h-96 bg-emerald-100 rounded-full blur-3xl opacity-30 pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-80 h-80 bg-teal-100 rounded-full blur-3xl opacity-25 pointer-events-none" />

        <div className="relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Text Content */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100/80 text-emerald-800 font-sans font-semibold text-xs tracking-wider uppercase shadow-sm mx-auto lg:mx-0">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              Lembaga Pelatihan & Penyedia Alat Terpercaya
            </div>

            <h1 className="font-sans font-extrabold text-3xl sm:text-4xl lg:text-5xl text-slate-800 tracking-tight leading-tight">
              Belajar Teknologi Modern, <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
                Amanah, Praktis, & Berkah
              </span>
            </h1>

            <p className="font-sans text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              Selamat datang di <strong>Barokah Tech Jambi Academy</strong>. Kami melayani pelatihan intensif bidang 
              Internet of Things (IoT), Robotika, AI, dan Web Development secara <em>hands-on</em>. 
              Tersedia juga kit belajar/alat teknik bergaransi untuk mendukung proses belajar Anda dari nol sampai ahli. 
              Kami juga menyediakan pelayanan pemasangan Starlink, Setting Mikrotik untuk Hotspot dan Pemasangan CCTV IP Cam maupun Analog.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onExploreCourses}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/20 hover:shadow-emerald-600/35 transition-all duration-300 cursor-pointer"
                id="hero-cta-courses"
              >
                Jelajahi Kursus Kami
                <ArrowRight className="h-4 w-4" />
              </button>

              <button
                onClick={onOpenConsult}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-700 font-sans font-semibold text-sm border border-slate-200 hover:border-emerald-500 rounded-xl shadow-sm transition-all duration-300 cursor-pointer group"
                id="hero-cta-consult"
              >
                <Sparkles className="h-4 w-4 text-amber-500 group-hover:scale-110 transition-transform" />
                Tanya AI Advisor (Konsultasi Gratis)
              </button>
            </div>

            {/* Quick trust metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-100">
              <div className="text-center lg:text-left">
                <span className="block font-sans font-extrabold text-2xl text-emerald-600">500+</span>
                <span className="text-xs text-slate-500 font-medium">Alumni Kompeten</span>
              </div>
              <div className="text-center lg:text-left">
                <span className="block font-sans font-extrabold text-2xl text-emerald-600">100%</span>
                <span className="text-xs text-slate-500 font-medium">Praktik Hands-On</span>
              </div>
              <div className="text-center lg:text-left">
                <span className="block font-sans font-extrabold text-2xl text-emerald-600">24 Jam</span>
                <span className="text-xs text-slate-500 font-medium">AI Advisor Online</span>
              </div>
              <div className="text-center lg:text-left">
                <span className="block font-sans font-extrabold text-2xl text-emerald-600">Garansi</span>
                <span className="text-xs text-slate-500 font-medium">Kit Tukar Baru</span>
              </div>
            </div>
          </div>

          {/* Graphical/Image Container */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-sm sm:max-w-md">
              {/* Decorative behind card */}
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-600 to-teal-400 rounded-3xl rotate-6 scale-95 opacity-20 blur-sm pointer-events-none" />
              
              <div className="bg-white p-6 rounded-3xl shadow-xl border border-slate-100 space-y-6 relative">
                {/* Hero Card Image */}
                <img
                  src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80"
                  alt="IoT Electronics Lab"
                  referrerPolicy="no-referrer"
                  className="w-full h-48 object-cover rounded-2xl shadow-inner border border-slate-100"
                />

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold px-2.5 py-1 rounded bg-amber-50 text-amber-800 border border-amber-100">
                      ★ Rekomendasi Utama
                    </span>
                    <span className="text-xs text-slate-400 font-medium">6 Minggu Sesi</span>
                  </div>
                  <h3 className="font-sans font-bold text-lg text-slate-800">
                    IoT Smart Home & Automation
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Pelajari perakitan modul ESP32, sensor real-time, sirkuit relay tegangan AC, dan kontrol otomatisasi pintar berbasis Cloud.
                  </p>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-50">
                    <div>
                      <span className="text-[10px] text-slate-400 block line-through">Rp 1.100.000</span>
                      <span className="text-sm font-bold text-emerald-600 block">Rp 750.000 <span className="text-[10px] font-normal text-slate-500">(+Kit Fisik)</span></span>
                    </div>
                    <button
                      onClick={onExploreCourses}
                      className="px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-sans font-bold text-xs rounded-lg transition-colors cursor-pointer"
                    >
                      Buka Syllabus
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
}
