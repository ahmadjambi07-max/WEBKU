import { Star, ShoppingCart, Check, Info } from "lucide-react";
import React from "react";
import { Product } from "../types";

interface ProductCardProps {
  key?: React.Key;
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [isAdded, setIsAdded] = React.useState(false);

  // Format to Rupiah
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const handleAddClick = () => {
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
    }, 1500);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-150 overflow-hidden shadow-sm hover:shadow-md hover:border-emerald-200 transition-all duration-300 flex flex-col h-full" id={`product-card-${product.id}`}>
      {/* Product Image */}
      <div className="relative h-44 bg-slate-50 overflow-hidden group">
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Category tag */}
        <div className="absolute top-3 left-3">
          <span className="px-2 py-0.5 text-[9px] font-extrabold uppercase bg-slate-900/80 backdrop-blur-sm text-white rounded-md tracking-wider">
            {product.categoryLabel}
          </span>
        </div>
        {/* Stock Alert */}
        <div className="absolute bottom-3 right-3">
          {product.stock <= 15 ? (
            <span className="px-2 py-0.5 text-[9px] font-bold bg-amber-500 text-white rounded-md">
              Sisa {product.stock} unit
            </span>
          ) : (
            <span className="px-2 py-0.5 text-[9px] font-medium bg-emerald-500/90 text-white rounded-md">
              Ready Stock
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-grow flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center gap-1.5 mb-1.5">
            {/* Stars */}
            <div className="flex items-center text-amber-400">
              <Star className="h-3.5 w-3.5 fill-current" />
              <span className="text-xs font-bold text-slate-700 ml-1">{product.rating}</span>
            </div>
            <span className="text-xs text-slate-400">({product.reviewsCount} ulasan)</span>
          </div>

          <h3 className="font-sans font-bold text-sm text-slate-800 line-clamp-2 hover:text-emerald-700 transition-colors">
            {product.name}
          </h3>

          <p className="text-xs text-slate-500 line-clamp-2 mt-1 leading-relaxed">
            {product.description}
          </p>

          {/* Quick specs */}
          <div className="mt-2.5">
            <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Isi Kit / Specs:</span>
            <div className="space-y-0.5">
              {product.specs.slice(0, 2).map((spec, index) => (
                <div key={index} className="text-[11px] text-slate-600 truncate flex items-center gap-1">
                  <span className="h-1 w-1 bg-emerald-500 rounded-full flex-shrink-0" />
                  <span>{spec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Pricing and Action */}
        <div className="pt-3 border-t border-slate-50 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 block">Harga Pas</span>
            <span className="text-base font-extrabold text-slate-800">{formatRupiah(product.price)}</span>
          </div>

          <button
            onClick={handleAddClick}
            disabled={product.stock === 0}
            className={`px-3 py-2 rounded-xl text-xs font-bold font-sans transition-all flex items-center gap-1 cursor-pointer ${
              isAdded
                ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                : product.stock === 0
                ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                : "bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm hover:shadow"
            }`}
            id={`add-to-cart-${product.id}`}
          >
            {isAdded ? (
              <>
                <Check className="h-3.5 w-3.5" />
                Masuk!
              </>
            ) : product.stock === 0 ? (
              "Habis"
            ) : (
              <>
                <ShoppingCart className="h-3.5 w-3.5" />
                Beli
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
