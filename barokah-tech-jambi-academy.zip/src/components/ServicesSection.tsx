import React from "react";
import { Globe, Cpu, Video, Monitor, ArrowRight, CheckCircle2, PhoneCall } from "lucide-react";

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  icon: React.ComponentType<{ className?: string }>;
  highlights: string[];
  pricingInfo: string;
  waText: string;
}

const SERVICES_DATA: ServiceItem[] = [
  {
    id: "web-development",
    title: "Pembuatan Website Sekolah (PPDB), Kantor & Lembaga",
    description: "Website modern, cepat, dan responsif dengan fitur PPDB online, profil sekolah, portal administrasi, serta web profile kantor/lembaga profesional.",
    longDescription: "Kami menghadirkan solusi digital lengkap untuk instansi pendidikan dan perkantoran. Dilengkapi dengan sistem pendaftaran siswa baru (PPDB online), galeri kegiatan, modul berita, hingga integrasi database yang aman dan mudah dikelola oleh admin sekolah atau kantor Anda.",
    icon: Globe,
    highlights: [
      "Sistem PPDB Online & Kelola Formulir Siswa Baru",
      "Termasuk Domain (.sch.id / .com) & Hosting Premium",
      "Desain Responsif (Sempurna di HP & Laptop)",
      "Pelatihan Admin/Operator sampai bisa",
      "Keamanan Website Terjamin & SSL Gratis"
    ],
    pricingInfo: "Mulai dari Rp 1.850.000 (Sesuai Kebutuhan Fitur)",
    waText: "Halo Admin Barokah Tech Jambi Academy, saya tertarik dengan jasa Pembuatan Website Sekolah/Kantor. Mohon info detail untuk paket harganya ya, terima kasih!"
  },
  {
    id: "robotics-kids",
    title: "Kursus Robotik untuk Siswa SD, SMP, SMA & Umum",
    description: "Program belajar merakit & memprogram robot pintar untuk anak usia sekolah hingga dewasa menggunakan kit interaktif dari nol sampai mahir.",
    longDescription: "Metode pembelajaran menyenangkan berbasis STEM (Science, Technology, Engineering, Mathematics). Siswa akan diajarkan dari dasar pengenalan komponen elektronik, sensor, cara menyusun algoritma logika, hingga memprogram robot penghindar rintangan, line follower, atau robot kontrol nirkabel.",
    icon: Cpu,
    highlights: [
      "Kurikulum disesuaikan tingkat usia (SD / SMP / SMA / Umum)",
      "Kit robotik interaktif disediakan (bisa dibawa pulang)",
      "Pilihan kelas Privat / Reguler (Online maupun Tatap Muka)",
      "Mendapatkan Sertifikat Kelulusan Resmi",
      "Kesempatan bimbingan kompetisi robotik tingkat nasional"
    ],
    pricingInfo: "Mulai dari Rp 150.000/Sesi (Tersedia Paket Bulanan)",
    waText: "Halo Admin Barokah Tech Jambi Academy, saya ingin mendaftar/bertanya mengenai Kursus Robotik untuk Anak/Umum. Mohon kirimkan brosur kelas dan jadwalnya ya, terima kasih!"
  },
  {
    id: "cctv-install",
    title: "Pemesanan & Jasa Pemasangan CCTV (IP Cam / Analog)",
    description: "Solusi keamanan 24 jam dengan instalasi kabel rapi, kamera resolusi tinggi, dan pemantauan online langsung dari smartphone Anda kapan pun.",
    longDescription: "Layanan survei lokasi gratis, perencanaan penempatan kamera untuk area blind spot, pemesanan unit kamera berkualitas (brand terkemuka bergaransi resmi), hingga instalasi kabel terstruktur. Melayani perumahan, toko, ruko, perkantoran, tempat ibadah, sekolah, dan area gudang.",
    icon: Video,
    highlights: [
      "Kamera resolusi tinggi (IP Cam Full HD / Analog AHD)",
      "Setting online ke HP (Pantau jarak jauh gratis selamanya)",
      "Instalasi kabel rapi, aman, dan berstandar teknis",
      "Garansi resmi perangkat & garansi instalasi lembaga",
      "Penyimpanan rekam cerdas dengan notifikasi deteksi gerak"
    ],
    pricingInfo: "Paket Lengkap mulai dari Rp 1.450.000 (Termasuk Alat & Jasa)",
    waText: "Halo Admin Barokah Tech Jambi Academy, saya berminat untuk memesan dan memasang CCTV di rumah/kantor saya. Mohon informasi paket CCTV yang tersedia dan jadwal surveinya, terima kasih!"
  },
  {
    id: "pc-assembly",
    title: "Pemesanan & Perakitan PC / Komputer Kustom",
    description: "Perakitan komputer handal untuk kebutuhan administrasi sekolah, laboratorium komputer, editing video, desain grafis, hingga gaming.",
    longDescription: "Bantu Anda menyusun komputer dengan kombinasi komponen terbaik sesuai anggaran. Semua part dijamin baru, original, dan bergaransi resmi. Kami pastikan melakukan pengujian performa mendalam (stability stress test) sebelum komputer dikirimkan ke lokasi Anda.",
    icon: Monitor,
    highlights: [
      "Konsultasi pemilihan spesifikasi gratis (disesuaikan budget)",
      "Komponen 100% Baru & Bergaransi Resmi per item",
      "Instalasi Sistem Operasi & Software Pendukung (Siap pakai)",
      "Manajemen kabel (Cable Management) rapi di dalam casing",
      "Gratis pengiriman & instalasi set di tempat (Jambi & sekitarnya)"
    ],
    pricingInfo: "Disesuaikan budget Anda (Biaya perakitan sangat terjangkau)",
    waText: "Halo Admin Barokah Tech Jambi Academy, saya ingin berkonsultasi spesifikasi komputer untuk kebutuhan sekolah/editing/kantor. Budget saya sekitar Rp ... Mohon bantuannya, terima kasih!"
  }
];

interface ServicesSectionProps {
  selectedServiceId?: string;
  onSelectServiceId?: (id: string) => void;
}

export default function ServicesSection({ selectedServiceId, onSelectServiceId }: ServicesSectionProps) {
  const [localSelectedService, setLocalSelectedService] = React.useState<string>(SERVICES_DATA[0].id);

  const activeId = selectedServiceId !== undefined ? selectedServiceId : localSelectedService;
  const setActiveId = onSelectServiceId !== undefined ? onSelectServiceId : setLocalSelectedService;

  const activeService = SERVICES_DATA.find(s => s.id === activeId) || SERVICES_DATA[0];

  return (
    <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" id="services">
      <div className="bg-white/95 backdrop-blur-md border border-slate-200 shadow-xl rounded-3xl p-6 sm:p-12">
        
        {/* Section Header */}
        <div className="text-center space-y-3 mb-12">
          <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider bg-emerald-50 px-3 py-1 rounded-full inline-block">
            Layanan Unggulan Kami
          </span>
          <h2 className="font-sans font-extrabold text-2xl sm:text-3xl text-slate-800 tracking-tight">
            Jenis Pelayanan Barokah Tech Jambi
          </h2>
          <p className="text-sm text-slate-500 max-w-xl mx-auto leading-relaxed">
            Tidak hanya mendidik, kami hadir memberikan solusi teknologi integratif, amanah, tanpa biaya tersembunyi, dan insya Allah berkah.
          </p>
        </div>

        {/* Desktop Layout (Tabs + Detail) & Mobile list */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT: Nav Tabs / Cards */}
          <div className="lg:col-span-5 space-y-3">
            <span className="block text-slate-400 font-sans font-bold text-[10px] uppercase tracking-wider pl-1 mb-1">
              PILIH JENIS PELAYANAN:
            </span>
            {SERVICES_DATA.map((service) => {
              const Icon = service.icon;
              const isSelected = activeId === service.id;
              return (
                <button
                  key={service.id}
                  onClick={() => setActiveId(service.id)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 cursor-pointer flex gap-4 items-start ${
                    isSelected
                      ? "border-emerald-500 bg-white shadow-md shadow-emerald-600/5 ring-1 ring-emerald-500/10"
                      : "border-slate-200 hover:border-slate-300 hover:bg-slate-50/50 bg-white"
                  }`}
                  id={`service-tab-${service.id}`}
                >
                  <div className={`p-2.5 rounded-xl flex-shrink-0 transition-colors ${
                    isSelected ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-500"
                  }`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className={`font-sans font-extrabold text-xs leading-snug ${
                      isSelected ? "text-slate-800" : "text-slate-700"
                    }`}>
                      {service.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>


          {/* RIGHT: Selected Service Details */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-slate-150 shadow-sm space-y-6">
            
            {/* Header detail */}
            <div className="flex gap-4 items-center pb-5 border-b border-slate-100">
              <div className="bg-emerald-50 text-emerald-600 p-3.5 rounded-2xl">
                {React.createElement(activeService.icon, { className: "h-6 w-6" })}
              </div>
              <div>
                <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider bg-emerald-50/50 px-2 py-0.5 rounded">
                  Layanan Resmi
                </span>
                <h3 className="font-sans font-extrabold text-base sm:text-lg text-slate-800 leading-tight mt-1">
                  {activeService.title}
                </h3>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-3">
              <p className="text-xs text-slate-600 leading-relaxed">
                {activeService.longDescription}
              </p>
            </div>

            {/* Highlights List */}
            <div className="space-y-3 bg-slate-50 p-5 rounded-2xl border border-slate-100">
              <span className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                Keunggulan & Cakupan Layanan:
              </span>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                {activeService.highlights.map((hl, i) => (
                  <li key={i} className="flex items-start gap-2 text-slate-600 leading-tight">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                    <span>{hl}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bottom info & Call to action */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-100">
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Estimasi Investasi/Biaya:</span>
                <span className="text-sm font-extrabold text-emerald-700 block mt-0.5">{activeService.pricingInfo}</span>
                <span className="text-[9px] text-slate-400 font-medium leading-none block mt-0.5">Sesuai akad tanpa bunga, denda, atau riba.</span>
              </div>

              <a
                href={`https://wa.me/6282377387548?text=${encodeURIComponent(activeService.waText)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/10 hover:shadow-emerald-600/20 transition-all cursor-pointer w-full sm:w-auto justify-center"
                id={`btn-wa-service-${activeService.id}`}
              >
                <PhoneCall className="h-4 w-4" />
                Pesan / Tanya Jasa Sekarang
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
