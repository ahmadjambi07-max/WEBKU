import React from "react";
import { ShoppingCart, Cpu, Menu, X, Sparkles, ChevronDown } from "lucide-react";

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
  onOpenConsult: () => void;
  onSelectService: (serviceId: string) => void;
}

export default function Navbar({
  cartCount,
  onCartClick,
  activeSection,
  setActiveSection,
  onOpenConsult,
  onSelectService,
}: NavbarProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = React.useState(false);
  const [isMobileDropdownOpen, setIsMobileDropdownOpen] = React.useState(false);

  const navItems = [
    { id: "home", label: "Beranda" },
    { id: "courses", label: "Kursus & Pelatihan" },
    { id: "products", label: "Toko Alat & Kit" },
    { id: "faq", label: "Tanya Jawab (FAQ)" },
  ];

  const servicesMenu = [
    { id: "web-development", label: "Website Sekolah & PPDB" },
    { id: "robotics-kids", label: "Kursus Robotik SD-SMA" },
    { id: "cctv-install", label: "Pemesanan & Pasang CCTV" },
    { id: "pc-assembly", label: "Pemesanan & Rakit PC" },
  ];

  const handleNavClick = (sectionId: string) => {
    setActiveSection(sectionId);
    setIsOpen(false);
    setIsDropdownOpen(false);
    
    // Scroll to section smoothly
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleServiceClick = (serviceId: string) => {
    onSelectService(serviceId);
    setActiveSection("services");
    setIsOpen(false);
    setIsDropdownOpen(false);
    setIsMobileDropdownOpen(false);

    // Scroll to services section smoothly
    const element = document.getElementById("services");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-emerald-50 shadow-sm" id="main-navbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => handleNavClick("home")}
              className="flex items-center gap-2 text-left cursor-pointer focus:outline-none"
              id="brand-logo-btn"
            >
              <div className="bg-emerald-600 text-white p-2 rounded-xl shadow-md shadow-emerald-200 flex items-center justify-center">
                <Cpu className="h-6 w-6" />
              </div>
              <div>
                <span className="font-sans font-bold text-lg text-slate-800 tracking-tight block leading-tight">
                  Barokah Tech Jambi
                </span>
                <span className="font-sans text-xs text-emerald-600 font-medium block tracking-wider -mt-0.5">
                  ACADEMY
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-1">
            <button
              onClick={() => handleNavClick("home")}
              className={`px-4 py-2 rounded-lg font-sans font-medium text-sm transition-all duration-200 cursor-pointer ${
                activeSection === "home"
                  ? "text-emerald-700 bg-emerald-50"
                  : "text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
              }`}
              id="nav-home"
            >
              Beranda
            </button>

            {/* Dropdown Jenis Pelayanan */}
            <div 
              className="relative"
              onMouseEnter={() => setIsDropdownOpen(true)}
              onMouseLeave={() => setIsDropdownOpen(false)}
            >
              <button
                className={`px-4 py-2 rounded-lg font-sans font-medium text-sm transition-all duration-200 cursor-pointer flex items-center gap-1 ${
                  activeSection === "services"
                    ? "text-emerald-700 bg-emerald-50 font-semibold"
                    : "text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
                }`}
                id="nav-services-dropdown-btn"
                onClick={() => handleNavClick("services")}
              >
                Jenis Pelayanan
                <ChevronDown className={`h-3 w-3 transition-transform ${isDropdownOpen ? "rotate-180" : ""}`} />
              </button>

              {isDropdownOpen && (
                <div className="absolute left-0 mt-0 w-64 bg-white border border-slate-100 rounded-2xl shadow-xl py-2 z-50 animate-fade-in">
                  {servicesMenu.map((service) => (
                    <button
                      key={service.id}
                      onClick={() => handleServiceClick(service.id)}
                      className="block w-full text-left px-4 py-2.5 text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 font-sans transition-colors cursor-pointer"
                    >
                      {service.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {navItems.filter(item => item.id !== "home").map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-2 rounded-lg font-sans font-medium text-sm transition-all duration-200 cursor-pointer ${
                  activeSection === item.id
                    ? "text-emerald-700 bg-emerald-50"
                    : "text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
                }`}
                id={`nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}

            {/* AI Advisor Button */}
            <button
              onClick={onOpenConsult}
              className="ml-2 flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-500 text-white rounded-lg font-sans font-semibold text-xs tracking-wide shadow-sm hover:opacity-95 transition-opacity cursor-pointer animate-pulse"
              id="nav-ai-advisor"
            >
              <Sparkles className="h-3.5 w-3.5" />
              KONSULTASI AI
            </button>
          </div>

          {/* Cart & Mobile menu button */}
          <div className="flex items-center gap-2">
            {/* Cart Button */}
            <button
              onClick={onCartClick}
              className="relative p-2 text-slate-600 hover:text-emerald-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
              id="cart-badge-trigger"
              aria-label="Keranjang Belanja"
            >
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-rose-500 rounded-full animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile menu toggle */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="inline-flex items-center justify-center p-2 rounded-lg text-slate-500 hover:text-emerald-600 hover:bg-slate-50 focus:outline-none cursor-pointer"
                id="mobile-menu-btn"
              >
                {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-100 shadow-inner px-2 pt-2 pb-4 space-y-1">
          <button
            onClick={() => handleNavClick("home")}
            className={`block w-full text-left px-4 py-2.5 rounded-lg font-sans font-medium text-sm transition-all ${
              activeSection === "home"
                ? "text-emerald-700 bg-emerald-50 font-semibold"
                : "text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
            }`}
          >
            Beranda
          </button>

          {/* Mobile Dropdown for Jenis Pelayanan */}
          <div className="space-y-1">
            <button
              onClick={() => setIsMobileDropdownOpen(!isMobileDropdownOpen)}
              className="flex items-center justify-between w-full text-left px-4 py-2.5 rounded-lg font-sans font-medium text-sm text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
            >
              <span>Jenis Pelayanan</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${isMobileDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {isMobileDropdownOpen && (
              <div className="pl-6 space-y-1 bg-slate-50/50 py-1 rounded-lg">
                {servicesMenu.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => handleServiceClick(service.id)}
                    className="block w-full text-left px-4 py-2 text-xs text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-md font-sans transition-all py-2 cursor-pointer"
                  >
                    • {service.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {navItems.filter(item => item.id !== "home").map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`block w-full text-left px-4 py-2.5 rounded-lg font-sans font-medium text-sm transition-all ${
                activeSection === item.id
                  ? "text-emerald-700 bg-emerald-50 font-semibold"
                  : "text-slate-600 hover:text-emerald-600 hover:bg-slate-50"
              }`}
              id={`mobile-nav-${item.id}`}
            >
              {item.label}
            </button>
          ))}
          <button
            onClick={() => {
              setIsOpen(false);
              onOpenConsult();
            }}
            className="flex items-center justify-center gap-2 w-full mt-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-500 text-white rounded-lg font-sans font-semibold text-sm shadow-sm"
            id="mobile-nav-ai-advisor"
          >
            <Sparkles className="h-4 w-4" />
            Mulai Konsultasi AI Cerdas
          </button>
        </div>
      )}

    </nav>
  );
}
