import React, { useEffect, useState } from "react";
import { motion } from "motion/react";

interface FloatingNode {
  id: number;
  text: string;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  colorClass: string;
  glowColor: string;
  type: "code" | "binary" | "tag" | "chip";
}

const MODERN_TECH_SNIPPETS = [
  "const [status, setStatus] = useState('active');",
  "await ai.generateContent({ prompt });",
  "interface AcademyStudent { id: string; name: string; }",
  "01100010 01100001 01101111",
  "npm run build && node server.js",
  "useEffect(() => { streamLiveIOT() }, []);",
  "mqtt.publish('jambi/academy/iot', telemetry);",
  "git push origin main -u",
  "const db = getFirestore();",
  "import { motion } from 'motion/react';",
  "const socket = new WebSocket('wss://api.barokah.tech');",
  "const model = 'gemini-2.5-flash';",
  "analogRead(A0); // Read IoT Sensor Data",
  "<BarokahTechAcademy />",
  "System.out.println(\"Hello Jambi Tech\");",
  "const [iotState, setIotState] = useState();",
  "// 100% Real IoT & Coding Training",
  "0xFA3C99 // Hex Memory Allocation",
  "const server = express();",
  "docker-compose up -d --build"
];

const COLORS = [
  { text: "text-cyan-400", glow: "rgba(34, 211, 238, 0.2)" },
  { text: "text-blue-400", glow: "rgba(96, 165, 250, 0.2)" },
  { text: "text-indigo-400", glow: "rgba(129, 140, 248, 0.2)" },
  { text: "text-emerald-400", glow: "rgba(52, 211, 153, 0.2)" },
  { text: "text-purple-400", glow: "rgba(192, 132, 252, 0.2)" }
];

export default function TechBackgroundAnimation() {
  const [nodes, setNodes] = useState<FloatingNode[]>([]);

  useEffect(() => {
    // Generate randomized tech objects
    const generatedNodes: FloatingNode[] = Array.from({ length: 30 }).map((_, i) => {
      const colorSet = COLORS[Math.floor(Math.random() * COLORS.length)];
      const text = MODERN_TECH_SNIPPETS[Math.floor(Math.random() * MODERN_TECH_SNIPPETS.length)];
      const types: Array<"code" | "binary" | "tag" | "chip"> = ["code", "binary", "tag", "chip"];

      return {
        id: i,
        text,
        x: Math.random() * 92 + 4, // 4% to 96%
        y: Math.random() * 100,
        size: Math.floor(Math.random() * 5) + 11, // 11px to 15px
        duration: Math.floor(Math.random() * 35) + 30, // 30s to 65s drift
        delay: Math.random() * -30, // instant pre-population
        colorClass: colorSet.text,
        glowColor: colorSet.glow,
        type: types[Math.floor(Math.random() * types.length)]
      };
    });
    setNodes(generatedNodes);
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0" id="tech-background-animation">
      
      {/* 1. Large Ambient Pulsing Nebula Orbs (Very modern aesthetic) */}
      <div className="absolute top-[15%] left-[20%] w-[350px] sm:w-[500px] h-[350px] sm:h-[500px] bg-cyan-500/10 rounded-full glow-orb-1" />
      <div className="absolute bottom-[20%] right-[15%] w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] bg-indigo-500/10 rounded-full glow-orb-2" />
      <div className="absolute top-[60%] left-[5%] w-[300px] h-[300px] bg-emerald-500/5 rounded-full glow-orb-1" />

      {/* 2. Cyberpunk Tech Vector Grid Lines (Glowing Circuit board elements) */}
      <div className="absolute inset-0 opacity-[0.06] bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

      {/* 3. Glowing Laser Digital Stream Columns (Dynamic & Professional) */}
      <div className="absolute inset-0 opacity-15 flex justify-between select-none">
        {Array.from({ length: 12 }).map((_, idx) => {
          // Alternative dynamic colors for each laser column
          const colors = ["text-cyan-500/40", "text-blue-500/40", "text-indigo-500/40", "text-emerald-500/40", "text-purple-500/40"];
          const colColor = colors[idx % colors.length];
          return (
            <div 
              key={`laser-column-${idx}`} 
              className={`flex flex-col font-mono text-[9px] ${colColor} gap-2 select-none`}
              style={{ 
                animation: `scrollColumn ${40 + (idx * 6)}s linear infinite`,
                animationDelay: `${idx * -4.5}s`,
                transform: "translateY(-100%)"
              }}
            >
              {Array.from({ length: 30 }).map((_, charIdx) => (
                <span key={charIdx} className="font-mono tracking-widest text-center">
                  {Math.random() > 0.4 ? "1" : "0"}
                </span>
              ))}
            </div>
          );
        })}
      </div>

      {/* 4. Drifting Modern Coding Snippets with glowing micro-cards */}
      {nodes.map((node) => {
        return (
          <motion.div
            key={node.id}
            initial={{ 
              x: `${node.x}vw`, 
              y: Math.random() > 0.5 ? "-15%" : "115%", 
              opacity: 0 
            }}
            animate={{
              y: Math.random() > 0.5 ? "115%" : "-15%",
              opacity: [0, 0.45, 0.45, 0]
            }}
            transition={{
              duration: node.duration,
              repeat: Infinity,
              ease: "linear",
              delay: node.delay,
              times: [0, 0.1, 0.9, 1]
            }}
            className="absolute font-mono pointer-events-none select-none whitespace-nowrap bg-slate-900/45 backdrop-blur-sm px-2.5 py-1 rounded-md border border-slate-800/60 shadow-lg flex items-center gap-1.5"
            style={{
              fontSize: `${node.size}px`,
              boxShadow: `0 0 10px ${node.glowColor}`,
              borderLeft: `2.5px solid ${node.colorClass.replace("text-", "").replace("-400", "") === "cyan" ? "#22d3ee" : node.colorClass.replace("text-", "").replace("-400", "") === "emerald" ? "#34d399" : "#818cf8"}`
            }}
          >
            {/* Cute visual dot helper indicator */}
            <span className={`inline-block w-1.5 h-1.5 rounded-full ${node.colorClass} animate-pulse`} />
            <span className={`${node.colorClass} opacity-80`}>{node.text}</span>
          </motion.div>
        );
      })}

      {/* CSS keyframes for optimized stream scrolling */}
      <style>{`
        @keyframes scrollColumn {
          0% {
            transform: translateY(-50%);
          }
          100% {
            transform: translateY(150%);
          }
        }
      `}</style>
    </div>
  );
}
