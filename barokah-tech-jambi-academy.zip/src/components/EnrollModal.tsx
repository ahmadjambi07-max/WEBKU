import { X, CheckCircle, GraduationCap, ShieldCheck, Mail, Phone, MapPin, ClipboardList, Send } from "lucide-react";
import React from "react";
import { Course } from "../types";

interface EnrollModalProps {
  course: Course | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function EnrollModal({ course, isOpen, onClose }: EnrollModalProps) {
  const [step, setStep] = React.useState<"form" | "invoice">("form");
  
  // Form State
  const [classType, setClassType] = React.useState<"online" | "offline">("online");
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [address, setAddress] = React.useState("");
  
  // Generated Registration Invoice Info
  const [regId, setRegId] = React.useState("");
  const [uniqueCode, setUniqueCode] = React.useState(0);

  React.useEffect(() => {
    if (isOpen) {
      setStep("form");
      setClassType("online");
      setUniqueCode(Math.floor(Math.random() * 90) + 10); // 10-99
    }
  }, [isOpen]);

  if (!isOpen || !course) return null;

  // Format price
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const currentPrice = classType === "online" ? course.priceOnline : course.priceOffline;
  const totalPayment = currentPrice + uniqueCode;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone) return;
    if (classType === "offline" && !address) return;

    // Generate Reg ID
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const randNum = Math.floor(Math.random() * 900) + 100;
    setRegId(`REG-BTA-${dateStr}-${randNum}`);
    
    setStep("invoice");
  };

  const handleFinish = () => {
    setStep("form");
    setName("");
    setEmail("");
    setPhone("");
    setAddress("");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto" id="enroll-modal">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
        onClick={step !== "invoice" ? onClose : undefined}
      />

      <div className="bg-white rounded-3xl shadow-2xl border border-emerald-50 max-w-lg w-full overflow-hidden relative z-10 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-700 to-teal-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6" />
            <div>
              <h3 className="font-sans font-bold text-sm tracking-tight">Pendaftaran Kursus</h3>
              <p className="text-[10px] text-emerald-100 font-medium">Lembaga Barokah Tech Jambi Academy</p>
            </div>
          </div>
          {step !== "invoice" && (
            <button 
              onClick={onClose} 
              className="p-1 text-emerald-100 hover:text-white hover:bg-emerald-600/40 rounded-lg transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-grow overflow-y-auto p-6 space-y-4">
          <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100/50 flex gap-3">
            <img 
              src={course.image} 
              alt={course.title} 
              className="h-14 w-14 object-cover rounded-xl border border-white shadow-sm flex-shrink-0"
            />
            <div>
              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded uppercase">
                {course.categoryLabel}
              </span>
              <h4 className="font-sans font-extrabold text-sm text-slate-800 mt-1 leading-tight">{course.title}</h4>
              <p className="text-[10px] text-slate-500 font-medium mt-0.5">Durasi: {course.duration}</p>
            </div>
          </div>

          {/* STEP 1: REGISTRATION FORM */}
          {step === "form" && (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Class Type selector */}
              <div>
                <span className="block text-[11px] font-bold text-slate-500 mb-2">Pilihan Paket Belajar:</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setClassType("online")}
                    className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      classType === "online"
                        ? "border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20"
                        : "border-slate-200 hover:border-slate-300 bg-white"
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-800">Kelas Online</span>
                    <span className="text-[10px] text-slate-500 mt-0.5">Akses via Zoom & LMS</span>
                    <span className="text-sm font-extrabold text-emerald-700 mt-2">{formatRupiah(course.priceOnline)}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setClassType("offline")}
                    className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      classType === "offline"
                        ? "border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20"
                        : "border-slate-200 hover:border-slate-300 bg-white"
                    }`}
                  >
                    <span className="text-xs font-bold text-slate-800">Offline + Kit Fisik</span>
                    <span className="text-[10px] text-emerald-600 font-medium mt-0.5">Komponen dikirim</span>
                    <span className="text-sm font-extrabold text-emerald-700 mt-2">{formatRupiah(course.priceOffline)}</span>
                  </button>
                </div>
              </div>

              {/* Personal Details */}
              <div className="space-y-3 pt-1">
                <span className="block text-[11px] font-bold text-slate-500 uppercase tracking-wide">Data Diri Calon Siswa:</span>
                
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 mb-1">Nama Lengkap *</label>
                    <input 
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Contoh: Muhammad Akhyar"
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white text-slate-800 font-sans"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">Alamat Email *</label>
                      <input 
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="contoh@email.com"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white text-slate-800 font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">No. WhatsApp Aktif *</label>
                      <input 
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="Contoh: 082377387548"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white text-slate-800 font-sans"
                      />
                    </div>
                  </div>

                  {classType === "offline" && (
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 mb-1">Alamat Pengiriman Kit Komponen *</label>
                      <textarea 
                        required
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        rows={2}
                        placeholder="Alamat lengkap tujuan pengiriman kit belajar fisik"
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white text-slate-800 font-sans resize-none"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Syllabus Overview */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide block mb-1.5">Materi yang akan dipelajari:</span>
                <ul className="space-y-1">
                  {course.syllabus.slice(0, 4).map((syl, index) => (
                    <li key={index} className="text-[10px] text-slate-600 flex items-start gap-1">
                      <span className="text-emerald-500 font-bold">•</span>
                      <span>{syl}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="text-[10px] text-slate-400 flex items-start gap-1">
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>Setelah mendaftar, Anda akan mendapatkan invoice pendaftaran & rincian instruksi akses portal pembelajaran (LMS).</span>
              </div>

              <button 
                type="submit"
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/15 cursor-pointer text-center block transition-all"
                id="modal-enroll-submit"
              >
                Kirim Pendaftaran & Dapatkan Invoice
              </button>
            </form>
          )}

          {/* STEP 2: INVOICE / RECEIPT */}
          {step === "invoice" && (
            <div className="space-y-4">
              {/* Receipt Success Banner */}
              <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-center space-y-1.5">
                <div className="inline-flex p-1.5 bg-emerald-100 text-emerald-700 rounded-full">
                  <CheckCircle className="h-5 w-5" />
                </div>
                <h4 className="font-sans font-bold text-sm text-emerald-800">Pendaftaran Berhasil Terkirim!</h4>
                <p className="text-[10.5px] text-emerald-700 leading-normal">
                  Satu langkah lagi! Silakan selesaikan pembayaran infaq pendaftaran di bawah ini untuk aktivasi portal LMS.
                </p>
              </div>

              {/* Invoice Layout */}
              <div className="bg-slate-50 p-4 rounded-2xl border-2 border-dashed border-slate-200 space-y-3 font-mono text-xs text-slate-700">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="font-extrabold text-emerald-700">BAROKAH TECH ACADEMY</span>
                  <span className="text-[9px] text-slate-400">ID: {regId}</span>
                </div>

                <div className="space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Kelas:</span>
                    <span className="font-bold text-slate-800 text-right max-w-[200px] truncate">{course.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Metode:</span>
                    <span className="font-bold text-slate-800 uppercase">{classType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Nama Siswa:</span>
                    <span className="font-bold text-slate-800">{name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Syllabus Akses:</span>
                    <span className="font-bold text-emerald-600">6 Modul Utama</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 space-y-1 text-[11px]">
                  <div className="flex justify-between">
                    <span>Biaya Kursus:</span>
                    <span>{formatRupiah(currentPrice)}</span>
                  </div>
                  <div className="flex justify-between text-amber-600">
                    <span>Kode Unik Verifikasi:</span>
                    <span>+{uniqueCode}</span>
                  </div>
                  <div className="flex justify-between text-xs font-bold text-slate-900 border-t border-slate-200 pt-2">
                    <span>TOTAL TRANSFER:</span>
                    <span className="text-emerald-700 text-sm font-extrabold">{formatRupiah(totalPayment)}</span>
                  </div>
                </div>
              </div>

              {/* VA Bank Transfer */}
              <div className="bg-emerald-600/5 p-4 rounded-xl border border-emerald-600/10 space-y-3">
                <span className="text-xs font-bold text-emerald-800 block">Metode Pembayaran (Transfer Bank Syariah):</span>
                
                <div className="bg-white p-3 rounded-lg border border-emerald-100 flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">Bank Syariah Indonesia (BSI)</span>
                    <span className="text-sm font-mono font-extrabold text-slate-800 tracking-wider">712-345-6789</span>
                    <span className="text-[10px] text-slate-500 block">a.n. Yayasan Barokah Tech Jambi Academy</span>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded">BSI</span>
                </div>

                <div className="text-[10px] text-slate-500 leading-normal space-y-1 bg-white p-3 rounded-lg border border-slate-100">
                  <p className="font-bold text-slate-700">📌 Petunjuk Verifikasi:</p>
                  <p>1. Harap transfer sesuai nominal persis: <strong>{formatRupiah(totalPayment)}</strong>.</p>
                  <p>2. Konfirmasikan bukti transfer ke admin agar kelas & portal LMS Anda dapat diaktifkan segera.</p>
                </div>
              </div>

              {/* WA Confirmation and Close buttons */}
              <div className="space-y-2">
                <a 
                  href={`https://wa.me/6282377387548?text=Assalamualaikum%20Admin%20Barokah%20Tech%20Academy%2C%20saya%20telah%20mendaftar%20kelas%20${encodeURIComponent(course.title)}%20(${classType})%20dengan%20ID%20Pendaftaran%20${regId}.%20Total%20transfer%3A%20${encodeURIComponent(formatRupiah(totalPayment))}.%20Mohon%20bantuan%20aktivasi%20kelas%20saya%20ya%20Kak%2C%20terima%20kasih!`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-md text-center block transition-colors cursor-pointer"
                  id="wa-confirm-enroll"
                >
                  Konfirmasi via WhatsApp Admin
                </a>

                <button 
                  type="button"
                  onClick={handleFinish}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-white font-sans font-bold text-xs rounded-xl text-center block transition-colors cursor-pointer"
                >
                  Selesai & Tutup
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
