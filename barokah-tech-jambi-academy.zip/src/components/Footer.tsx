import { Cpu, Phone, Mail, MapPin, CheckSquare, ShieldAlert } from "lucide-react";

interface FooterProps {
  onNavClick: (sectionId: string) => void;
}

export default function Footer({ onNavClick }: FooterProps) {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Brand and Mission */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-emerald-600 text-white p-1.5 rounded-xl flex items-center justify-center">
                <Cpu className="h-5 w-5" />
              </div>
              <span className="font-sans font-extrabold text-lg tracking-tight text-white">
                Barokah Tech Jambi Academy
              </span>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed">
              Lembaga pelatihan teknologi intensif dan penyedia modul starter kit / komponen elektronika 
              bergaransi di Indonesia. Berkomitmen mencetak talenta unggul secara amanah, praktis, dan insya Allah berkah.
            </p>

            <div className="pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-900 rounded-full">
                <CheckSquare className="h-3 w-3" />
                Lembaga Terverifikasi & Resmi
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="font-sans font-bold text-sm text-white tracking-wide">Navigasi</h4>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavClick("home")} className="hover:text-emerald-400 transition-colors cursor-pointer text-left">
                  Beranda
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick("courses")} className="hover:text-emerald-400 transition-colors cursor-pointer text-left">
                  Kursus Pelatihan
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick("products")} className="hover:text-emerald-400 transition-colors cursor-pointer text-left">
                  Toko Alat & Kit
                </button>
              </li>
              <li>
                <button onClick={() => onNavClick("faq")} className="hover:text-emerald-400 transition-colors cursor-pointer text-left">
                  Tanya Jawab FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Contact and address */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="font-sans font-bold text-sm text-white tracking-wide">Hubungi Kami</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                <span className="whitespace-pre-line leading-relaxed">
                  Perumahan Citra Raya City Jambi{"\n"}
                  Mendalo Darat, Jambi Luar Kota{"\n"}
                  Muaro Jambi{"\n"}
                  Provinsi Jambi
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                <span>+62 823-7738-7548</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                <span>advertisingbarokahstore@gmail.com</span>
              </li>
            </ul>
          </div>

          {/* Business Integrity (Syariah friendly trust factors) */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="font-sans font-bold text-sm text-white tracking-wide">Prinsip Jual Beli</h4>
            <div className="bg-slate-850 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <p className="font-semibold text-emerald-400 flex items-center gap-1">
                ⚖️ Syariah & Amanah
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Semua sanksi jual beli, spesifikasi starter kit, dan akad biaya pelatihan kami paparkan secara transparan di awal tanpa ada biaya tersembunyi (Gharar).
              </p>
            </div>
          </div>

        </div>

        {/* Bottom copyright metadata */}
        <div className="pt-8 mt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} Barokah Tech Jambi Academy. Seluruh Hak Cipta Dilindungi.</p>
          <div className="flex gap-4">
            <span className="hover:text-slate-400 transition-colors cursor-default">Syarat & Ketentuan</span>
            <span className="hover:text-slate-400 transition-colors cursor-default">Kebijakan Privasi</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
