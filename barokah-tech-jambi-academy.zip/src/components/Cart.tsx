import { X, Trash2, Plus, Minus, ShoppingBag, ShieldCheck, CheckCircle2, ArrowRight } from "lucide-react";
import React from "react";
import { CartItem } from "../types";

interface CartProps {
  items: CartItem[];
  isOpen: boolean;
  onClose: () => void;
  onUpdateQuantity: (productId: string, newQuantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function Cart({
  items,
  isOpen,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartProps) {
  const [checkoutStep, setCheckoutStep] = React.useState<"cart" | "form" | "invoice">("cart");
  
  // Checkout Form State
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [address, setAddress] = React.useState("");
  const [courier, setCourier] = React.useState("JNT");
  
  // Generated Invoice Details
  const [invoiceId, setInvoiceId] = React.useState("");
  const [uniqueCode, setUniqueCode] = React.useState(0);

  React.useEffect(() => {
    if (isOpen) {
      // Reset checkout steps on reopen
      setCheckoutStep("cart");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee = subtotal > 0 ? 15000 : 0; // Flat Rp 15.000
  const total = subtotal + deliveryFee + uniqueCode;

  // Format to Rupiah
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const handleStartCheckout = () => {
    setUniqueCode(Math.floor(Math.random() * 90) + 10); // Code 10-99
    setCheckoutStep("form");
  };

  const getWhatsAppUrl = (currentInvoiceId?: string) => {
    const activeInvoiceId = currentInvoiceId || invoiceId;
    const itemsListText = items.map((item, index) => 
      `${index + 1}. ${item.product.name} (x${item.quantity}) - ${formatRupiah(item.product.price * item.quantity)}`
    ).join("\n");

    const messageText = `Assalamualaikum Admin Barokah Tech Jambi Academy, saya ingin memproses pemesanan produk. Berikut rincian pesanan saya:

*Detail Pesanan:*
• No. Invoice: ${activeInvoiceId}
• Nama Lengkap: ${name}
• No. WhatsApp: ${phone}
• Kurir Pengiriman: ${courier} Express
• Alamat Pengiriman: ${address}

*Daftar Produk:*
${itemsListText}

*Rincian Biaya:*
• Subtotal: ${formatRupiah(subtotal)}
• Ongkir Kurir Flat: ${formatRupiah(deliveryFee)}
• Kode Unik Transaksi: +${uniqueCode}
• *Total Transfer: ${formatRupiah(total)}*

Mohon bantuannya untuk memproses pesanan ini ya Kak. Terima kasih!`;

    return `https://wa.me/6282377387548?text=${encodeURIComponent(messageText)}`;
  };

  const handleSubmitCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !address) return;

    // Generate Invoice ID
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
    const randNum = Math.floor(Math.random() * 9000) + 1000;
    const generatedId = `BTA-${dateStr}-${randNum}`;
    setInvoiceId(generatedId);
    
    // Auto open WhatsApp with the beautifully formatted order details
    const waUrl = getWhatsAppUrl(generatedId);
    window.open(waUrl, "_blank");

    setCheckoutStep("invoice");
  };

  const handleFinish = () => {
    onClearCart();
    onClose();
    setCheckoutStep("cart");
    setName("");
    setPhone("");
    setAddress("");
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" id="cart-overlay">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm transition-opacity" 
        onClick={checkoutStep !== "invoice" ? onClose : undefined}
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col h-full border-l border-emerald-50">
          {/* Header */}
          <div className="px-4 py-5 bg-gradient-to-r from-emerald-700 to-teal-600 text-white flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              <h2 className="font-sans font-bold text-base">
                {checkoutStep === "cart" && "Keranjang Belanja"}
                {checkoutStep === "form" && "Formulir Pengiriman"}
                {checkoutStep === "invoice" && "Invoice Pembayaran"}
              </h2>
            </div>
            {checkoutStep !== "invoice" && (
              <button 
                onClick={onClose} 
                className="p-1 text-emerald-100 hover:text-white hover:bg-emerald-600/50 rounded-lg transition-colors cursor-pointer"
                id="close-cart-btn"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>

          {/* Core Content area */}
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            
            {/* STEP 1: CART LIST */}
            {checkoutStep === "cart" && (
              <>
                {items.length === 0 ? (
                  <div className="h-64 flex flex-col items-center justify-center text-center space-y-3">
                    <div className="p-4 bg-emerald-50 text-emerald-600 rounded-full">
                      <ShoppingBag className="h-10 w-10" />
                    </div>
                    <p className="font-sans font-medium text-sm text-slate-500">Keranjang belanja Anda kosong</p>
                    <button 
                      onClick={onClose} 
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
                    >
                      Mulai Belanja Alat
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {items.map((item) => (
                      <div 
                        key={item.product.id} 
                        className="flex gap-3 bg-white p-3 rounded-xl border border-slate-150 shadow-sm relative group"
                        id={`cart-item-${item.product.id}`}
                      >
                        <img 
                          src={item.product.image} 
                          alt={item.product.name} 
                          className="h-16 w-16 object-cover rounded-lg border border-slate-100"
                        />
                        <div className="flex-grow min-w-0 pr-6">
                          <h4 className="font-sans font-bold text-xs text-slate-800 truncate">
                            {item.product.name}
                          </h4>
                          <p className="text-[11px] text-slate-400 font-medium">
                            {formatRupiah(item.product.price)} / unit
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            {/* Quantity buttons */}
                            <button 
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                              className="p-1 border border-slate-200 rounded hover:bg-slate-50 text-slate-600 cursor-pointer"
                              id={`qty-minus-${item.product.id}`}
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="text-xs font-bold font-mono text-slate-700 w-4 text-center">
                              {item.quantity}
                            </span>
                            <button 
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                              className="p-1 border border-slate-200 rounded hover:bg-slate-50 text-slate-600 cursor-pointer"
                              id={`qty-plus-${item.product.id}`}
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                        
                        {/* Remove item button */}
                        <button 
                          onClick={() => onRemoveItem(item.product.id)}
                          className="absolute top-3 right-3 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          id={`remove-item-${item.product.id}`}
                          title="Hapus"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    
                    {/* Clear Button */}
                    <div className="flex justify-end">
                      <button 
                        onClick={onClearCart} 
                        className="text-[11px] font-bold text-rose-500 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        Kosongkan Keranjang
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* STEP 2: CHECKOUT FORM */}
            {checkoutStep === "form" && (
              <form onSubmit={handleSubmitCheckout} className="space-y-4 pt-1" id="checkout-shipping-form">
                <div className="space-y-3 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wide block">Data Pemesan</span>
                  
                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Nama Lengkap *</label>
                    <input 
                      type="text" 
                      required 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Masukkan nama lengkap Anda"
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white font-sans text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">No. WhatsApp Aktif *</label>
                    <input 
                      type="tel" 
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="Contoh: 082377387548"
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white font-sans text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Alamat Lengkap Pengiriman *</label>
                    <textarea 
                      required
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      rows={3}
                      placeholder="Nama jalan, Nomor rumah, RT/RW, Kecamatan, Kota/Kabupaten, Kode Pos"
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white font-sans text-slate-800 resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-500 mb-1">Ekspedisi Kurir</label>
                    <select 
                      value={courier} 
                      onChange={(e) => setCourier(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none bg-white font-sans text-slate-800"
                    >
                      <option value="JNT">J&T Express (Flat Rp 15.000)</option>
                      <option value="JNE">JNE REG (Flat Rp 15.000)</option>
                      <option value="SICEPAT">Sicepat Halu (Flat Rp 15.000)</option>
                    </select>
                  </div>
                </div>

                <div className="text-[10px] text-slate-400 flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 flex-shrink-0" />
                  <span>Transaksi amanah & terenkripsi. Sesuai prinsip jual beli syariah yang transparan.</span>
                </div>

                <button 
                  type="submit" 
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors text-center block"
                  id="submit-shipping-btn"
                >
                  Proses Jual Beli / Buat Invoice
                </button>
                
                <button 
                  type="button" 
                  onClick={() => setCheckoutStep("cart")}
                  className="w-full py-2 bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 font-sans font-semibold text-xs rounded-xl cursor-pointer transition-colors text-center block"
                >
                  Kembali ke Keranjang
                </button>
              </form>
            )}

            {/* STEP 3: GENERATED INVOICE */}
            {checkoutStep === "invoice" && (
              <div className="space-y-4 pt-1" id="checkout-invoice-view">
                {/* Visual Banner Success */}
                <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-center space-y-2">
                  <div className="inline-flex p-1.5 bg-emerald-100 text-emerald-700 rounded-full">
                    <CheckCircle2 className="h-5 w-5" />
                  </div>
                  <h3 className="font-sans font-bold text-sm text-emerald-800">Alhamdulillah, Pesanan Dibuat!</h3>
                  <p className="text-[11px] text-emerald-700 leading-normal">
                    Silakan lakukan transfer sesuai rincian di bawah ini untuk proses packing & pengiriman.
                  </p>
                </div>

                {/* Invoice Paper details */}
                <div className="bg-slate-50 p-4 rounded-2xl border-2 border-dashed border-slate-200 space-y-4 font-mono text-xs text-slate-700">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <span className="font-bold text-emerald-700">BAROKAH TECH ACADEMY</span>
                    <span className="text-[10px] text-slate-400">TGL: {new Date().toLocaleDateString("id-ID")}</span>
                  </div>

                  <div className="space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">No. Invoice:</span>
                      <span className="font-bold text-slate-800">{invoiceId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Pelanggan:</span>
                      <span className="font-bold text-slate-800">{name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">WhatsApp:</span>
                      <span className="font-bold text-slate-800">{phone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Kurir:</span>
                      <span className="font-bold text-slate-800">{courier} Express</span>
                    </div>
                  </div>

                  {/* Items list */}
                  <div className="py-2.5 border-t border-b border-slate-200 space-y-2">
                    <span className="font-bold text-slate-500 text-[10px] uppercase block">Daftar Barang:</span>
                    {items.map((item) => (
                      <div key={item.product.id} className="flex justify-between text-[11px]">
                        <span className="truncate max-w-[200px]">{item.product.name} (x{item.quantity})</span>
                        <span className="font-bold">{formatRupiah(item.product.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Calculations */}
                  <div className="space-y-1 text-[11px] pt-1">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{formatRupiah(subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ongkir Kurir Flat:</span>
                      <span>{formatRupiah(deliveryFee)}</span>
                    </div>
                    <div className="flex justify-between text-amber-600">
                      <span>Kode Unik Transaksi:</span>
                      <span>+{uniqueCode}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-900 border-t border-slate-200 pt-2">
                      <span>TOTAL TRANSFER:</span>
                      <span className="text-emerald-700 text-sm font-extrabold">{formatRupiah(total)}</span>
                    </div>
                  </div>
                </div>

                {/* Transfer Info */}
                <div className="bg-emerald-600/5 p-4 rounded-xl border border-emerald-600/10 space-y-3">
                  <span className="text-xs font-bold text-emerald-800 block">Metode Pembayaran Syariah (Transfer):</span>
                  
                  <div className="bg-white p-3 rounded-lg border border-emerald-100 flex justify-between items-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">Bank Syariah Indonesia (BSI)</span>
                      <span className="text-sm font-mono font-extrabold text-slate-800 tracking-wider">712-345-6789</span>
                      <span className="text-[10px] text-slate-500 block">a.n. Yayasan Barokah Tech Jambi Academy</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded">BSI</span>
                  </div>

                  <div className="text-[11px] text-slate-600 leading-normal space-y-1.5">
                    <p className="font-bold text-slate-700">💡 Instruksi Penting:</p>
                    <p>1. Transfer tepat sampai digit terakhir: <strong>{formatRupiah(total)}</strong> agar sistem mendeteksi otomatis.</p>
                    <p>2. Ambil foto/screenshot bukti transfer.</p>
                    <p>3. Konfirmasikan pembayaran dengan mengirimkan bukti transfer ke WA Admin dengan menekan tombol di bawah.</p>
                  </div>
                </div>

                {/* Confirm Action */}
                <a 
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-md text-center block transition-colors cursor-pointer"
                  id="wa-confirm-btn"
                >
                  Konfirmasi via WhatsApp
                </a>

                <button 
                  type="button"
                  onClick={handleFinish}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-xs rounded-xl text-center block transition-colors cursor-pointer"
                >
                  Selesai & Tutup
                </button>
              </div>
            )}

          </div>

          {/* STEP 1 FOOTER: CALCULATIONS & CHECKOUT TRIGGER */}
          {checkoutStep === "cart" && items.length > 0 && (
            <div className="p-4 border-t border-slate-100 bg-slate-50 space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Subtotal Belanja:</span>
                  <span className="font-semibold font-mono">{formatRupiah(subtotal)}</span>
                </div>
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Estimasi Ongkos Kirim:</span>
                  <span className="font-semibold font-mono">{formatRupiah(deliveryFee)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-800 border-t border-slate-200/50 pt-2">
                  <span>Estimasi Total:</span>
                  <span className="text-emerald-700 font-mono font-extrabold">{formatRupiah(subtotal + deliveryFee)}</span>
                </div>
              </div>

              <button
                onClick={handleStartCheckout}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-colors text-center flex items-center justify-center gap-1.5 cursor-pointer"
                id="cart-checkout-btn"
              >
                Lanjut ke Pengiriman
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
