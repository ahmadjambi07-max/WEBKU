import { Sparkles, MessageSquare, X, Send, Cpu, ChevronDown, CheckCircle2, AlertTriangle } from "lucide-react";
import React from "react";
import { ChatMessage } from "../types";

interface AIAssistantProps {
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
}

export default function AIAssistant({ isOpen, onOpen, onClose }: AIAssistantProps) {
  const [messages, setMessages] = React.useState<ChatMessage[]>([
    {
      sender: "bot",
      text: "Assalamualaikum! Selamat datang di Barokah Tech Jambi Academy. Saya adalah **AI Advisor** resmi Anda.\n\nAda yang bisa saya bantu hari ini? Anda bisa berkonsultasi mengenai:\n1. 🎓 **Rekomendasi kursus** yang cocok dengan karir atau minat Anda.\n2. 🔌 **Pemilihan kit belajar** atau alat elektronika untuk hobi/proyek Anda.\n3. 💡 **Troubleshooting** dasar sirkuit atau coding mikrokontroler.\n\nSilakan tanyakan apa saja, Kak! 😊",
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = React.useState("");
  const [isLoading, setIsLoading] = React.useState(false);
  
  const chatEndRef = React.useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  React.useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading, isOpen]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    // Add user message
    const userMsg: ChatMessage = {
      sender: "user",
      text: text,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInputText("");
    setIsLoading(true);

    try {
      // Send to Express Backend API route
      const response = await fetch("/api/consult", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-8) // Send last 8 messages for context
        }),
      });

      if (!response.ok) {
        throw new Error("Gagal menghubungi server AI.");
      }

      const data = await response.json();
      
      const botMsg: ChatMessage = {
        sender: "bot",
        text: data.response || "Maaf Kak, terjadi kendala saat merumuskan jawaban. Silakan coba kembali.",
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error("AI Error:", error);
      const errorMsg: ChatMessage = {
        sender: "bot",
        text: "Afwan Kak, sepertinya koneksi internet sedang terganggu atau layanan AI kami sedang padat. Silakan dicoba beberapa saat lagi, ya. Semoga berkah selalu!",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  // Quick suggestions
  const suggestions = [
    "Rekomendasi kelas IoT untuk pemula?",
    "Alat apa saja di kit ESP32?",
    "Mau bikin robot penghindar rintangan, beli apa?",
    "Ada kelas pemrograman web fullstack?"
  ];

  // Helper to parse simple markdown bold elements inside message text
  const renderMessageText = (text: string) => {
    return text.split("\n").map((line, lineIdx) => {
      // Parse markdown bold **text**
      const parts = line.split(/\*\*(.*?)\*\*/g);
      const renderedLine = parts.map((part, partIdx) => {
        // odd indices are the captured bold text
        if (partIdx % 2 === 1) {
          return <strong key={partIdx} className="font-extrabold text-slate-900">{part}</strong>;
        }
        return part;
      });

      return (
        <span key={lineIdx} className="block mb-1.5 leading-relaxed text-xs">
          {renderedLine}
        </span>
      );
    });
  };

  return (
    <>
      {/* Floating launcher badge when collapsed */}
      {!isOpen && (
        <button
          onClick={onOpen}
          className="fixed bottom-6 right-6 z-40 p-4 bg-gradient-to-r from-emerald-600 to-teal-500 text-white rounded-2xl shadow-xl shadow-emerald-600/30 hover:shadow-emerald-600/55 hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-2 cursor-pointer border border-emerald-400/20 group animate-bounce"
          id="ai-floating-launcher"
          title="Tanya AI Advisor"
        >
          <div className="relative">
            <MessageSquare className="h-6 w-6" />
            <span className="absolute top-0 right-0 h-2.5 w-2.5 bg-rose-500 border-2 border-white rounded-full animate-ping" />
          </div>
          <span className="font-sans font-bold text-xs tracking-wider">TANYA AI ADVISOR</span>
        </button>
      )}

      {/* Expanded Chat Box */}
      {isOpen && (
        <div 
          className="fixed bottom-6 right-6 z-40 w-80 sm:w-96 h-[500px] bg-white rounded-2xl border border-emerald-100 shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300"
          id="ai-chat-window"
        >
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-emerald-700 to-teal-600 text-white flex items-center justify-between shadow">
            <div className="flex items-center gap-2.5">
              <div className="bg-emerald-500/20 p-1.5 rounded-xl border border-emerald-400/30 flex items-center justify-center">
                <Cpu className="h-5 w-5 text-emerald-100" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-sm tracking-tight flex items-center gap-1">
                  Barokah AI Advisor
                  <Sparkles className="h-3 w-3 text-amber-300 animate-pulse" />
                </h3>
                <span className="text-[10px] text-emerald-100/90 flex items-center gap-1 font-medium">
                  <span className="h-1.5 w-1.5 bg-emerald-300 rounded-full animate-ping inline-block" />
                  Sistem Aktif & Terpercaya
                </span>
              </div>
            </div>
            
            <button 
              onClick={onClose} 
              className="p-1 text-emerald-100 hover:text-white hover:bg-emerald-600/40 rounded-lg transition-colors cursor-pointer"
              id="close-ai-chat"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages Log area */}
          <div className="flex-grow overflow-y-auto p-4 bg-slate-50 space-y-4">
            {messages.map((msg, index) => (
              <div 
                key={index}
                className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl p-3.5 shadow-sm border ${
                    msg.sender === "user"
                      ? "bg-emerald-600 text-white border-emerald-700 rounded-tr-none"
                      : "bg-white text-slate-700 border-slate-150 rounded-tl-none"
                  }`}
                >
                  <div className="text-xs">
                    {renderMessageText(msg.text)}
                  </div>
                  <span className={`text-[9px] block text-right mt-1.5 font-medium ${
                    msg.sender === "user" ? "text-emerald-100" : "text-slate-400"
                  }`}>
                    {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
              </div>
            ))}

            {/* AI Typing Loader */}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white text-slate-700 border border-slate-150 rounded-2xl rounded-tl-none p-3.5 shadow-sm space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <span className="h-2 w-2 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <span className="h-2 w-2 bg-emerald-500 rounded-full animate-bounce" />
                  </div>
                  <span className="text-[9px] text-slate-400 block font-medium">Memikirkan solusi terbaik...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* suggested question chips */}
          {messages.length === 1 && !isLoading && (
            <div className="p-3 bg-white border-t border-slate-100">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">Saran Pertanyaan:</span>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(s)}
                    className="text-[10px] font-medium text-slate-600 hover:text-emerald-700 bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 px-2.5 py-1 rounded-lg transition-all text-left cursor-pointer"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Form input */}
          <form onSubmit={handleFormSubmit} className="p-3 bg-white border-t border-slate-100 flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Tanyakan rekomendasi kelas / kit alat..."
              className="flex-grow px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none text-slate-800 bg-white"
              id="ai-chat-input"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-md disabled:bg-slate-100 disabled:text-slate-400 disabled:shadow-none transition-all flex items-center justify-center cursor-pointer"
              id="ai-send-chat-btn"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
