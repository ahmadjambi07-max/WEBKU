import React from "react";
import { BookOpen, User, CheckCircle2, Award, Calendar } from "lucide-react";
import { Course } from "../types";

interface CourseCardProps {
  key?: React.Key;
  course: Course;
  onEnrollClick: (course: Course) => void;
}

export default function CourseCard({ course, onEnrollClick }: CourseCardProps) {
  // Format to Rupiah
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Pemula":
        return "bg-sky-50 text-sky-700 border-sky-100";
      case "Menengah":
        return "bg-amber-50 text-amber-700 border-amber-100";
      case "Mahir":
        return "bg-rose-50 text-rose-700 border-rose-100";
      default:
        return "bg-slate-50 text-slate-700 border-slate-100";
    }
  };

  const getCategoryIcon = (category: string) => {
    return <BookOpen className="h-3.5 w-3.5 text-emerald-600" />;
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-150 overflow-hidden shadow-sm hover:shadow-md hover:border-emerald-200 transition-all duration-300 flex flex-col h-full" id={`course-card-${course.id}`}>
      {/* Course Banner */}
      <div className="relative h-48 bg-slate-100 overflow-hidden">
        <img
          src={course.image}
          alt={course.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        {/* Level tag & Duration floating */}
        <div className="absolute top-3 left-3 flex gap-1.5">
          <span className={`px-2.5 py-1 text-xs font-bold border rounded-lg shadow-sm ${getLevelColor(course.level)}`}>
            {course.level}
          </span>
          <span className="px-2.5 py-1 text-xs font-bold bg-white/90 backdrop-blur-sm text-slate-700 border border-slate-200/50 rounded-lg shadow-sm flex items-center gap-1">
            <Calendar className="h-3 w-3 text-emerald-600" />
            {course.duration.split(" ")[0]} {course.duration.split(" ")[1] || ""}
          </span>
        </div>
        <div className="absolute bottom-3 right-3">
          <span className="px-2.5 py-1 text-[10px] font-extrabold uppercase bg-emerald-600 text-white rounded-md tracking-wider shadow-md">
            {course.categoryLabel}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-grow flex flex-col space-y-4">
        <h3 className="font-sans font-bold text-lg text-slate-800 line-clamp-1 hover:text-emerald-700 transition-colors">
          {course.title}
        </h3>

        <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed flex-grow">
          {course.description}
        </p>

        {/* Pricing structure */}
        <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100/80 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-semibold text-slate-500">Pilihan Kelas Online</span>
            <span className="text-sm font-bold text-emerald-600">{formatRupiah(course.priceOnline)}</span>
          </div>
          <div className="flex justify-between items-center pt-1.5 border-t border-slate-200/40">
            <span className="text-[11px] font-semibold text-slate-500 flex flex-col">
              Kelas Offline + Kit Alat
              <span className="text-[9px] text-emerald-600 font-normal">Komponen fisik dikirim</span>
            </span>
            <span className="text-sm font-extrabold text-emerald-700">{formatRupiah(course.priceOffline)}</span>
          </div>
        </div>

        {/* Short syllabus outline (First 3 items) */}
        <div>
          <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wide block mb-2">Materi Pokok:</span>
          <ul className="space-y-1">
            {course.syllabus.slice(0, 3).map((item, index) => (
              <li key={index} className="text-xs text-slate-600 flex items-start gap-1.5">
                <span className="text-emerald-500 font-bold mt-0.5">•</span>
                <span className="line-clamp-1">{item}</span>
              </li>
            ))}
            {course.syllabus.length > 3 && (
              <li className="text-[10px] text-emerald-600 font-semibold pl-2.5">
                + {course.syllabus.length - 3} materi mendalam lainnya...
              </li>
            )}
          </ul>
        </div>
      </div>

      {/* Action Footer */}
      <div className="p-5 pt-0 border-t border-slate-50">
        <button
          onClick={() => onEnrollClick(course)}
          className="w-full py-2.5 bg-slate-900 hover:bg-emerald-600 text-white font-sans font-bold text-xs rounded-xl shadow-sm transition-all duration-300 cursor-pointer text-center flex items-center justify-center gap-1.5"
          id={`enroll-btn-${course.id}`}
        >
          <Award className="h-4 w-4" />
          Daftar / Pelajari Syllabus
        </button>
      </div>
    </div>
  );
}
