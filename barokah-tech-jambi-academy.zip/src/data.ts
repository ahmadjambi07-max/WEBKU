import { Course, Product, Testimonial, FAQ } from "./types";

export const COURSES: Course[] = [
  {
    id: "course-iot-smart-home",
    title: "IoT Smart Home & Automation",
    category: "iot",
    categoryLabel: "Internet of Things",
    level: "Menengah",
    duration: "6 Minggu (12 Sesi)",
    priceOnline: 350000,
    priceOffline: 750000,
    description: "Kuasai ekosistem smart home dengan ESP32. Anda akan belajar mengintegrasikan sensor, aktuator, protokol MQTT, database Firebase, hingga kontrol suara Google Assistant / Blynk.",
    image: "https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=600&q=80",
    syllabus: [
      "Pengenalan ESP32 & Setup Arduino IDE",
      "Membaca Sensor Suhu, Kelembaban & Deteksi Gerak",
      "Kontrol Relay & Lampu Tegangan Tinggi secara Aman",
      "Protokol MQTT & Integrasi Broker Node-RED",
      "Firebase Realtime Database & Custom Dashboard",
      "Integrasi Blynk & Google Assistant / Alexa"
    ],
    features: [
      "Sertifikat Kelulusan Resmi",
      "Akses LMS & Rekaman Sesi Selamanya",
      "Bimbingan di Grup WA Komunitas Selamanya",
      "Kit IoT Dikirim ke Rumah (Pilihan Offline/Full-Kit)"
    ]
  },
  {
    id: "course-robotics-arduino",
    title: "Robotics & Microcontroller Dasar",
    category: "robotics",
    categoryLabel: "Robotika",
    level: "Pemula",
    duration: "4 Minggu (8 Sesi)",
    priceOnline: 250000,
    priceOffline: 550000,
    description: "Langkah awal terbaik untuk belajar sirkuit dan pemrograman. Dirancang khusus bagi pemula untuk merakit dan memprogram robot beroda cerdas pendeteksi halangan menggunakan Arduino Uno.",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=600&q=80",
    syllabus: [
      "Konsep Dasar Elektronika & Arus Listrik",
      "Pemrograman Dasar C++ Arduino (Variabel, Loop, Kondisi)",
      "Membaca Sensor Jarak Ultrasonik & Sensor Cahaya",
      "Menggerakkan Motor DC & Motor Servo via Driver L298N",
      "Algoritma Obstacle Avoidance (Menghindari Rintangan)",
      "Merakit Chassis Robot Mobil 2 Roda (Assembly & Debug)"
    ],
    features: [
      "Sertifikat Fisik & Digital",
      "E-Book Panduan Merakit Robot",
      "Konsultasi 1-on-1 dengan Instruktur",
      "Kit Robot Dikirim ke Rumah (Pilihan Offline/Full-Kit)"
    ]
  },
  {
    id: "course-web-dev",
    title: "Web Development Fullstack Kilat",
    category: "programming",
    categoryLabel: "Pemrograman",
    level: "Pemula",
    duration: "8 Minggu (16 Sesi)",
    priceOnline: 400000,
    priceOffline: 900000,
    description: "Bangun aplikasi web interaktif Anda sendiri. Kursus intensif dari dasar HTML, CSS, JavaScript, framework React modern, hingga server Node.js dan Express untuk backend.",
    image: "https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&w=600&q=80",
    syllabus: [
      "Dasar HTML5, CSS3, dan Responsive Design (Tailwind CSS)",
      "Dasar JavaScript Modern (ES6+), Array, Object & API Fetch",
      "React JS: Component, Props, State, Hooks (useState, useEffect)",
      "Routing & State Management di Client",
      "Backend dengan Node.js, Express, dan RESTful API",
      "Koneksi Database & Deployment Aplikasi ke Cloud Run"
    ],
    features: [
      "Portofolio 3 Aplikasi Web Siap Kerja",
      "Review Code oleh Developer Senior",
      "Review CV & Persiapan Karir",
      "Grup Premium Alumni"
    ]
  },
  {
    id: "course-ai-python",
    title: "Kecerdasan Buatan (AI) & Python Dasar",
    category: "ai",
    categoryLabel: "Kecerdasan Buatan",
    level: "Pemula",
    duration: "5 Minggu (10 Sesi)",
    priceOnline: 300000,
    priceOffline: 650000,
    description: "Pelajari bahasa pemrograman paling populer di dunia dan aplikasikan ke kecerdasan buatan. Belajar mengolah data, deteksi wajah, dan membuat chatbot cerdas dengan API Gemini.",
    image: "https://images.unsplash.com/photo-1527474305487-b87b222841cc?auto=format&fit=crop&w=600&q=80",
    syllabus: [
      "Instalasi Python & Sintaks Dasar (List, Tuple, Dictionary, Function)",
      "Manipulasi Data dengan NumPy & Pandas",
      "Visualisasi Data dengan Matplotlib & Seaborn",
      "Computer Vision dasar menggunakan OpenCV (Deteksi Wajah & Warna)",
      "Pengenalan Machine Learning dengan Scikit-Learn",
      "Integrasi API Gemini untuk Membuat Aplikasi Chatbot Pintar"
    ],
    features: [
      "Source Code Template AI Siap Pakai",
      "Sertifikat Kompetensi AI",
      "Akses Server GPU untuk Praktik",
      "E-Certificate Terverifikasi"
    ]
  },
  {
    id: "course-iot-industry",
    title: "IoT Industri dengan ESP32 & Modbus RTU",
    category: "iot",
    categoryLabel: "Internet of Things",
    level: "Mahir",
    duration: "6 Minggu (12 Sesi)",
    priceOnline: 600000,
    priceOffline: 1200000,
    description: "Pelatihan khusus bagi profesional dan mahasiswa tingkat lanjut untuk mengintegrasikan ESP32 ke sistem industri menggunakan protokol Modbus RTU/TCP, sensor RS485, dan dashboard SCADA.",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=600&q=80",
    syllabus: [
      "Arsitektur IoT Industri (IIoT) & Keamanan Data",
      "Pengenalan RS485 & Protokol Modbus RTU",
      "Membaca Sensor Kelembaban Tanah & Weather Station Industri via RS485",
      "ESP32 sebagai Modbus Master & Slave",
      "Integrasi Gateway IoT Industri & Node-RED di Docker",
      "Visualisasi Data Sensor ke Dashboard Grafana & Alert System"
    ],
    features: [
      "Sertifikat Keahlian Khusus Industri",
      "Studi Kasus Proyek Nyata Pabrik / Perkebunan",
      "Dukungan Konsultasi Teknis Pasca Pelatihan",
      "Kit Modbus Komplet (Pilihan Offline/Full-Kit)"
    ]
  }
];

export const PRODUCTS: Product[] = [
  {
    id: "prod-arduino-kit",
    name: "Arduino Uno Starter Kit - Barokah Basic",
    category: "kit",
    categoryLabel: "Starter Kit",
    price: 185000,
    stock: 45,
    rating: 4.9,
    reviewsCount: 124,
    description: "Paket belajar lengkap mikrokontroler berbasis Arduino Uno R3. Sangat cocok untuk pemula, mahasiswa, dan anak sekolah yang ingin belajar pemrograman sirkuit elektronika dari nol. Disertai dengan e-book tutorial bahasa Indonesia yang disusun rapi.",
    image: "https://images.unsplash.com/photo-1608564697071-ddf911d8a37e?auto=format&fit=crop&w=600&q=80",
    specs: [
      "1x Board Arduino Uno R3 DIP (High Quality Clone)",
      "1x Breadboard 830 Lubang",
      "1x Kabel USB Arduino",
      "Sensor: Suhu LM35, Cahaya LDR, Jarak HC-SR04",
      "Output: 15x LED (Merah/Kuning/Hijau), 1x Buzzer, 1x Micro Servo SG90",
      "Pendukung: 30x Resistor (220, 1k, 10k), 40x Jumper Male-to-Male & Male-to-Female",
      "Bonus E-Book Panduan 20 Proyek Arduino Dasar"
    ]
  },
  {
    id: "prod-esp32-kit",
    name: "ESP32 IoT Developer Kit - Barokah Smart",
    category: "kit",
    categoryLabel: "IoT Kit",
    price: 225000,
    stock: 28,
    rating: 4.8,
    reviewsCount: 89,
    description: "Kit praktis untuk eksplorasi Internet of Things (IoT) berbasis ESP32 NodeMCU. NodeMCU ESP32 telah dilengkapi dengan modul WiFi dan Bluetooth onboard sehingga mempermudah pengiriman data sensor ke cloud seperti Blynk, Firebase, Thinger, atau broker MQTT.",
    image: "https://images.unsplash.com/photo-1517055720413-77a270441f87?auto=format&fit=crop&w=600&q=80",
    specs: [
      "1x NodeMCU ESP32 DEVKIT V1 WiFi+Bluetooth",
      "1x Sensor Suhu & Kelembaban Udara DHT11",
      "1x Sensor Cahaya LDR + Resistor Pembagi Tegangan",
      "1x Modul Relay 1 Channel 5V (Aman untuk Lampu AC)",
      "1x LCD Display 16x2 dengan Modul I2C Backpack",
      "1x Breadboard 400 Lubang & Kabel Micro USB",
      "30x Kabel Jumper Campuran",
      "Akses Link Google Drive Source Code Proyek IoT"
    ]
  },
  {
    id: "prod-robot-car",
    name: "Smart Car Robot Kit 2WD - Barokah Bot",
    category: "kit",
    categoryLabel: "Robotics Kit",
    price: 295000,
    stock: 15,
    rating: 4.9,
    reviewsCount: 63,
    description: "Paket lengkap merakit robot mobil beroda dua yang cerdas. Robot ini dapat menghindari rintangan (obstacle avoidance) atau dikendalikan melalui Bluetooth smartphone. Sangat baik untuk menguji pemahaman logika percabangan, pembacaan sensor jarak, dan kendali driver motor.",
    image: "https://images.unsplash.com/photo-1531746790731-6c087fecd05a?auto=format&fit=crop&w=600&q=80",
    specs: [
      "1x Board Arduino Uno R3 + Kabel USB",
      "1x Shield Driver Motor L298N / Shield Ekspansi Arduino",
      "1x Sensor Jarak Ultrasonik HC-SR04 + Bracket Akrilik",
      "1x Motor Servo SG90 (Pemutar Kepala Sensor)",
      "1x Chassis Akrilik Mobil Pintar + 2x Roda & Motor DC Gearbox",
      "1x Holder Baterai 18650 + 2x Baterai Li-Ion Reusable",
      "1x Modul Bluetooth HC-05 (Untuk Remote via HP)",
      "Panduan Perakitan Skema Kabel & Source Code Full"
    ]
  },
  {
    id: "prod-modbus-kit",
    name: "Industrial Modbus RS485 Kit",
    category: "kit",
    categoryLabel: "Industrial Kit",
    price: 450000,
    stock: 12,
    rating: 4.7,
    reviewsCount: 31,
    description: "Kit pembelajaran industrial Internet of Things. Menggunakan ESP32 untuk berkomunikasi dengan sensor industri berspesifikasi RS485 melalui protokol Modbus RTU. Cocok bagi praktisi industri, profesional IoT, atau mahasiswa yang sedang mengerjakan tugas akhir.",
    image: "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=600&q=80",
    specs: [
      "1x ESP32 NodeMCU DEVKIT V1",
      "1x Modul RS485 to TTL Auto-Direction (Converter)",
      "1x Sensor Kelembaban & Suhu Tanah Industri RS485 (IP68)",
      "1x LCD Display 128x64 dengan Adapter I2C",
      "1x Power Adapter 12V 2A & Terminal Block Connector",
      "Kabel Jumper Berkualitas Tinggi (Anti-Kendor)",
      "Studi Kasus: Log Data Sensor ke Database & Grafana"
    ]
  },
  {
    id: "prod-solder-adjustable",
    name: "Solder Listrik Adjustable Temp 60W + Stand",
    category: "tools",
    categoryLabel: "Peralatan",
    price: 85000,
    stock: 50,
    rating: 4.8,
    reviewsCount: 215,
    description: "Solder listrik dengan temperatur yang dapat disesuaikan secara manual dari 200°C hingga 450°C. Memudahkan penyolderan komponen halus seperti IC SMD hingga kabel tebal. Paket penjualan telah dilengkapi dengan timah gulung berkualitas tinggi dan mini stand solder.",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80",
    specs: [
      "Daya Listrik: 60 Watt, Tegangan: 220V AC",
      "Temperatur: Dapat diatur manual (200°C - 450°C)",
      "Bahan Ujung Tip: Logam berlapis krom (Panas merata)",
      "Panjang Kabel: 1.4 meter dengan pelindung kendor",
      "Include: 1x Solder, 1x Dudukan Solder Mini, 1x Timah Solder gulung (10 gram)"
    ]
  },
  {
    id: "prod-multimeter-digital",
    name: "Digital Multimeter Portable - Barokah Meter",
    category: "tools",
    categoryLabel: "Peralatan",
    price: 75000,
    stock: 35,
    rating: 4.7,
    reviewsCount: 142,
    description: "Multitester digital portabel berpresisi tinggi. Alat wajib untuk melakukan troubleshooting sirkuit elektronika, mendeteksi kerusakan kabel kendor, mengukur tegangan baterai, serta mengetes fungsionalitas dioda dan kontinuitas buzzer.",
    image: "https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=600&q=80",
    specs: [
      "Pengukuran: Tegangan AC/DC, Arus DC, Hambatan (Ohm)",
      "Fitur Spesial: Continuity Buzzer (Deteksi jalur putus), Diode Test",
      "Layar: LCD Display 3.5 digit jernih",
      "Proteksi: Fuse overload protection (Aman dari korsleting singkat)",
      "Kelengkapan: 1x Multimeter, 1x Set Kabel Probe Merah/Hitam, 1x Baterai 9V (Tinggal Pakai)"
    ]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "test-1",
    name: "Rizky Ramadhan",
    role: "Mahasiswa Teknik Elektro, ITS",
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80",
    rating: 5,
    comment: "Kursus IoT di Barokah Tech Jambi Academy sangat membantu skripsi saya! Instrukturnya sabar dan penjelasannya praktis, bukan teori semata. Kit ESP32-nya juga berkualitas tinggi dan pengirimannya cepat."
  },
  {
    id: "test-2",
    name: "Fatimah Az-Zahra",
    role: "Guru SMK Bidang Elektronika",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
    rating: 5,
    comment: "Lembaga yang luar biasa amanah. Kami memesan 20 paket Arduino Starter Kit untuk praktikum sekolah, harganya sangat bersaing dan diberikan bonus pendampingan instalasi gratis bagi guru-guru. Berkah selalu!"
  },
  {
    id: "test-3",
    name: "Budi Santoso",
    role: "Software Engineer, Startup Lokal",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
    rating: 4,
    comment: "Saya mengambil kelas Web Fullstack untuk refreshing React. Kurikulumnya up-to-date dengan tren industri sekarang. Sangat recommended buat yang mau berkarir di bidang IT!"
  }
];

export const FAQS: FAQ[] = [
  {
    id: "faq-1",
    question: "Apakah pemula tanpa dasar pemrograman bisa ikut?",
    answer: "Tentu saja! Kursus Robotics Arduino dan Web Development kami dirancang khusus dari dasar. Instruktur akan memandu Anda langkah demi langkah, mulai dari pengenalan sirkuit hingga penulisan kode pertama Anda."
  },
  {
    id: "faq-2",
    question: "Bagaimana sistem pengiriman Kit Alat untuk kursus?",
    answer: "Jika Anda memilih opsi 'Offline + Kit' atau 'Online + Full Kit', kami akan langsung memaketkan komponen fisik dari gudang Barokah Tech Jambi Academy dan mengirimkannya ke alamat Anda menggunakan ekspedisi tepercaya (JNE, J&T, Sicepat) lengkap dengan nomor resi."
  },
  {
    id: "faq-3",
    question: "Apakah mendapatkan sertifikat resmi?",
    answer: "Ya, setiap peserta yang menyelesaikan proyek akhir kursus dengan baik akan mendapatkan sertifikat kelulusan terverifikasi dari Barokah Tech Jambi Academy, lengkap dengan transkrip nilai kompetensi."
  },
  {
    id: "faq-4",
    question: "Bagaimana cara berkonsultasi jika ada error dalam perakitan?",
    answer: "Kami menyediakan forum diskusi khusus dan grup WhatsApp eksklusif alumni. Anda juga bisa menggunakan fitur AI Advisor di website ini untuk mendapatkan bantuan pemecahan kode / perakitan secara instan 24 jam!"
  }
];
